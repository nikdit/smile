// disable_right_click.js
document.addEventListener('contextmenu', function(event) {
    event.preventDefault();
  });
  